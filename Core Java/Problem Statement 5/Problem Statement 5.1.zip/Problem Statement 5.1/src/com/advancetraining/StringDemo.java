package com.advancetraining;

public class StringDemo {
	
	    public static void main(String[] args) {
				
			
			String txt= "JAVA is Simple";
			
			System.out.println(txt.toUpperCase()); //UpperCase
			System.out.println(txt.toLowerCase()); //LowerCase
			
			String str = "";
			String[] words=txt.split("\\s");	//1st words of letter
			
			StringBuilder words2= new StringBuilder();
			
			for(String w:words){  
				System.out.print(w.charAt(0)); 
				System.out.print(" ");
				str+=w;
				
			    StringBuilder revString = new StringBuilder(w);
	            
	            words2.append(revString.reverse());
	            words2.append(" ");
			}
			System.out.println(" ");
			//System.out.println();

			
			String[] words1=new String[words.length]; // Change order 
			int j = 0;

			for(int i = words.length-1; i>=0; i--){  
	            words1[j] = words[i];
	            
	            j++;
			}
			for(int i = 0; i<words1.length; i++){
			    System.out.print(words1[i]);
			    System.out.print(' ');
			}

			//String Builder reverse

			
			Object words21;
			System.out.println("String = " + words2.toString());
//	 		StringBuilder reverseStr = words2.reverse();
			//System.out.println("Reverse String = " + words2.toString());
			
			//Total Length
			System.out.println("length of string " + str.length());
	    }
	}
		
				